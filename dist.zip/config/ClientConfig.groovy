
brokerURL	  ="tcp://localhost:61616";
endpoint   = "EfExtractor"
casPoolSize   = 300

